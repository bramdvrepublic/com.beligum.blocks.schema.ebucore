xml-to-avro
===========

Converts an XML document to Avro and back.

Implementation of [AVRO-457](https://issues.apache.org/jira/browse/AVRO-457)